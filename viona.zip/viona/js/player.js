/* ═══════════════════════════════════════════════════════════════
   PLAYBACK — [FIXED] Real audio via HTML5 Audio + queue recycling
   ═══════════════════════════════════════════════════════════════ */
function loadTrack(i){
    // [FIXED] Queue recycling: when we've gone through all tracks, reshuffle
    if (!currentQueue.length) {
        currentQueue = buildPhaseAwareQueue([...DEMO_TRACKS]);
        showToast('Queue empty — rebuilding with demo tracks');
    }
    if (i >= currentQueue.length) {
        // Recycle: re-rank all tracks except disliked ones, reset index
        showToast('Reshuffling queue based on your feedback');
        const pool = currentQueue.filter(t => !preferences.dislikedTrackIds.has(t.id || t.name));
        if (pool.length < 3) {
            currentQueue = buildPhaseAwareQueue([...DEMO_TRACKS]);
        } else {
            // Reset session clock for new cycle
            sessionStartTime = Date.now();
            currentQueue = buildPhaseAwareQueue(pool);
        }
        i = 0;
    }

    clearPlayback();
    stopAudio(); // [FIXED] stop any playing audio
    currentTrackIndex = i % currentQueue.length;
    const t = currentQueue[currentTrackIndex];
    updateTrackUI(t);
    resetFeedbackUI();
    updateUpNext();

    // Try real audio if track has a preview URL
    if (t.previewUrl) {
        playRealAudio(t);
    } else {
        simulatePlayback(t.duration);
    }
    setPlayingState(true);
}

/** Play actual audio via HTML5 Audio element */
function playRealAudio(track) {
    clearPlayback();
    usingRealAudio = true;
    audioEl.src = track.previewUrl;
    audioEl.currentTime = 0;
    audioEl.play().catch(e => {
        console.warn('Audio play failed, falling back to simulation:', e);
        usingRealAudio = false;
        simulatePlayback(track.duration);
    });

    const dur = track.duration || 180;

    // Monitor real audio playback
    playbackInterval = setInterval(() => {
        if (!usingRealAudio) return;
        const ct = audioEl.currentTime;
        const total = audioEl.duration || dur;
        const pct = (ct / total) * 100;
        document.getElementById('progress-bar').style.width = Math.min(pct, 100) + '%';
        document.getElementById('current-time').textContent = fmt(Math.floor(ct));
        document.getElementById('total-time').textContent = fmt(Math.floor(total));
    }, 250);

    audioEl.onended = () => {
        clearPlayback();
        usingRealAudio = false;
        setTimeout(() => skipTrack(), 500);
    };
}

/** Stop real audio */
function stopAudio() {
    audioEl.pause();
    audioEl.src = '';
    audioEl.onended = null;
    usingRealAudio = false;
}

function simulatePlayback(s){
    clearPlayback();
    usingRealAudio = false;
    let p=0;
    document.getElementById('progress-bar').style.width='0%';
    document.getElementById('current-time').textContent='0:00';
    document.getElementById('total-time').textContent=fmt(s);
    playbackInterval=setInterval(()=>{
        p+=2;if(p>100)p=100;
        document.getElementById('progress-bar').style.width=p+'%';
        document.getElementById('current-time').textContent=fmt(Math.floor((p/100)*s));
        if(p>=100){clearPlayback();setTimeout(()=>skipTrack(),800)}
    },600);
}
function togglePlayPause(){
    if(isPlaying){
        if(serviceMode==='apple'&&musicInstance)musicInstance.pause();
        else if(usingRealAudio) audioEl.pause(); // [FIXED] pause real audio
        clearPlayback();setPlayingState(false);
    }else{
        if(serviceMode==='apple'&&musicInstance){musicInstance.play();startAppleMonitor()}
        else if(usingRealAudio){ audioEl.play(); startRealAudioMonitor(); } // [FIXED] resume real audio
        else{const t=currentQueue[currentTrackIndex];if(t)simulatePlayback(t.duration)}
        setPlayingState(true);
    }
}

/** Resume real audio monitoring after pause */
function startRealAudioMonitor() {
    clearPlayback();
    playbackInterval = setInterval(() => {
        if (!usingRealAudio) return;
        const ct = audioEl.currentTime;
        const total = audioEl.duration || (currentQueue[currentTrackIndex]?.duration || 180);
        const pct = (ct / total) * 100;
        document.getElementById('progress-bar').style.width = Math.min(pct, 100) + '%';
        document.getElementById('current-time').textContent = fmt(Math.floor(ct));
    }, 250);
}

function skipTrack(){
    if (!currentQueue.length) return;
    stopPlayback();
    stopAudio(); // [FIXED]
    const n=currentTrackIndex+1;
    if(serviceMode==='apple'&&musicInstance)loadAppleTrack(n);
    else loadTrack(n); // [FIXED] loadTrack now handles recycling
}
function previousTrack(){
    if (!currentQueue.length) return;
    stopPlayback();
    stopAudio(); // [FIXED]
    const p=Math.max(0,currentTrackIndex-1);
    if(serviceMode==='apple'&&musicInstance)loadAppleTrack(p);
    else loadTrack(p);
}
/** [P1-6] Pointer-based seek — supports tap + drag on progress bar */
function initProgressSeek() {
    const bar = document.getElementById('progress-track-el');
    if (!bar) return;
    let seeking = false;
    function doSeek(e) {
        const rect = bar.getBoundingClientRect();
        const p = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        document.getElementById('progress-bar').style.width = (p * 100) + '%';
        if (serviceMode === 'apple' && musicInstance && musicInstance.currentPlaybackDuration)
            musicInstance.seekToTime(p * musicInstance.currentPlaybackDuration);
        else if (usingRealAudio) audioEl.currentTime = p * (audioEl.duration || 30);
    }
    bar.addEventListener('pointerdown', (e) => { seeking = true; bar.setPointerCapture(e.pointerId); doSeek(e); });
    bar.addEventListener('pointermove', (e) => { if (seeking) doSeek(e); });
    bar.addEventListener('pointerup', () => { seeking = false; });
    bar.addEventListener('pointercancel', () => { seeking = false; });
}
function stopPlayback(){
    clearPlayback();
    if(serviceMode==='apple'&&musicInstance)try{musicInstance.stop()}catch(e){}
    setPlayingState(false);
}
function setPlayingState(p){
    isPlaying=p;
    document.getElementById('play-icon').style.display=p?'none':'block';
    document.getElementById('pause-icon').style.display=p?'block':'none';
}
function clearPlayback(){if(playbackInterval){clearInterval(playbackInterval);playbackInterval=null}}

