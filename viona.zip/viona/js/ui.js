/* ═══════════════════════════════════════════════════════════════
   SCREEN MANAGEMENT
   ═══════════════════════════════════════════════════════════════ */
function showScreen(id){
    document.querySelectorAll('.screen').forEach(s=>{s.style.display='none';s.classList.remove('active')});
    const el=document.getElementById(id);
    el.style.display='block';
    requestAnimationFrame(()=>{el.classList.add('active');window.scrollTo(0,0)});
}


/* ═══════════════════════════════════════════════════════════════
   UI HELPERS
   ═══════════════════════════════════════════════════════════════ */
function updateTrackUI(t){
    document.getElementById('track-name').textContent=t.name;
    document.getElementById('track-name').title=t.name;
    document.getElementById('artist-name').textContent=t.artist;
    document.getElementById('artist-name').title=t.artist;
    document.getElementById('album-name').textContent=t.album||'';
    document.getElementById('album-name').title=t.album||'';
    const img=document.getElementById('album-art-img'),ph=document.getElementById('album-art-placeholder');
    if(t.artUrl){img.src=t.artUrl;img.style.display='block';ph.style.display='none'}
    else{img.style.display='none';ph.style.display='block'}
    document.getElementById('progress-bar').style.width='0%';
    document.getElementById('current-time').textContent='0:00';
    document.getElementById('total-time').textContent=fmt(t.duration);

    // [FIXED] Show current phase + track energy
    const phaseE = getCurrentPhaseEnergy();
    const trackE = getTrackEnergy(t);
    const phaseInfo = ENERGY[phaseE] || {label:'Medium',color:'#c9a84c'};
    const trackInfo = ENERGY[trackE] || {label:'Medium',color:'#c9a84c'};

    // Determine phase name
    const elapsed = sessionStartTime ? (Date.now() - sessionStartTime) / 1000 : 0;
    const p1End = phases[1].duration * 60;
    const p2End = p1End + phases[2].duration * 60;
    let phaseName = 'Start';
    if (elapsed >= p2End) phaseName = 'End';
    else if (elapsed >= p1End) phaseName = 'Peak';

    const indicator = document.getElementById('phase-indicator');
    if (indicator) {
        indicator.innerHTML = `<span style="display:inline-flex;align-items:center;gap:6px"><span style="width:6px;height:6px;border-radius:50%;background:${phaseInfo.color}"></span>${phaseName} phase · ${phaseInfo.label} energy</span>`;
        indicator.style.display = 'block';
    }
}

/* [FIXED] Show up to 8 tracks in Up Next with energy indicators */
function updateUpNext(){
    const c=document.getElementById('up-next'),l=document.getElementById('up-next-list');
    const u=currentQueue.slice(currentTrackIndex+1,currentTrackIndex+9); // up to 8 tracks
    if(!u.length){c.style.display='none';return}
    c.style.display='block';
    l.innerHTML='';

    // [FIXED] Show current phase info
    const phaseEnergy = getCurrentPhaseEnergy();
    const phaseLabel = ENERGY[phaseEnergy]?.label || 'Medium';
    const phaseColor = ENERGY[phaseEnergy]?.color || '#c9a84c';

    u.forEach((t,i)=>{
        const trackEnergy = getTrackEnergy(t);
        const eColor = ENERGY[trackEnergy]?.color || '#c9a84c';
        const d=document.createElement('div');
        d.className='track-item';
        d.onclick=()=>{stopPlayback();stopAudio();if(serviceMode==='apple'&&musicInstance)loadAppleTrack(currentTrackIndex+1+i);else loadTrack(currentTrackIndex+1+i)};
        d.innerHTML=`<div style="width:36px;height:36px;border-radius:4px;overflow:hidden;background:var(--bg-warm);display:flex;align-items:center;justify-content:center;flex-shrink:0">${t.artUrl?'<img src="'+t.artUrl+'" style="width:100%;height:100%;object-fit:cover" loading="lazy"/>':'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" stroke-width="1"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55C7.79 13 6 14.79 6 17s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>'}</div><div style="flex:1;min-width:0"><div style="font-size:14px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${t.name}</div><div style="font-size:12px;color:var(--text-tertiary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${t.artist}</div></div><div style="display:flex;align-items:center;gap:8px;flex-shrink:0"><span style="width:6px;height:6px;border-radius:50%;background:${eColor};opacity:.7" title="Energy ${trackEnergy}"></span><span style="font-size:12px;color:var(--text-tertiary);font-variant-numeric:tabular-nums">${fmt(t.duration)}</span></div>`;
        l.appendChild(d);
    });
}

function showLoadingState(){
    document.getElementById('track-name').textContent='Finding music…';
    document.getElementById('artist-name').textContent='Searching';
    document.getElementById('album-name').textContent='';
    document.getElementById('album-art-img').style.display='none';
    document.getElementById('album-art-placeholder').style.display='block';
}


/* ═══════════════════════════════════════════════════════════════
   CHIPS
   ═══════════════════════════════════════════════════════════════ */
function toggleChip(t,x){activeChips[t].has(x)?activeChips[t].delete(x):activeChips[t].add(x);renderChips(t);updateChipButtons(t)}
function removeChip(t,x){activeChips[t].delete(x);renderChips(t);updateChipButtons(t)}

/** Sync visual state of chip-btn buttons with activeChips set */
function updateChipButtons(t) {
    document.querySelectorAll(`[onclick*="toggleChip('${t}'"]`).forEach(btn => {
        const txt = btn.textContent.trim();
        btn.classList.toggle('chip-btn-active', activeChips[t].has(txt));
    });
}

/** Add a custom genre typed by the user */
function addCustomGenre() {
    const input = document.getElementById('custom-genre-input');
    const val = input.value.trim();
    if (!val || val.length < 2) return;
    const genre = val.charAt(0).toUpperCase() + val.slice(1).toLowerCase();
    if (activeChips.genre.has(genre)) {
        showToast(genre + ' is already selected');
        input.value = '';
        return;
    }
    activeChips.genre.add(genre);
    renderChips('genre');
    updateChipButtons('genre');
    input.value = '';
    showToast('Added genre: ' + genre);
}

function renderChips(t){
    const c=document.getElementById(t+'-chips');c.innerHTML='';
    activeChips[t].forEach(x=>{
        const d=document.createElement('div');d.className='chip-active';
        const s=x.replace(/'/g,"\\'");
        d.innerHTML=`${x}<button onclick="removeChip('${t}','${s}')">×</button>`;
        c.appendChild(d);
    });
}

/* ═══════════════════════════════════════════════════════════════
   ENERGY PHASES
   ═══════════════════════════════════════════════════════════════ */
function initEnergyPhases(){
    document.querySelectorAll('.energy-phase').forEach(el=>{
        const p=parseInt(el.dataset.phase),dots=el.querySelector('.energy-dots'),slider=el.querySelector('.phase-slider');
        for(let i=1;i<=5;i++){const b=document.createElement('button');b.className='energy-dot';b.dataset.level=i;b.setAttribute('aria-label','Energy level '+i+' – '+ENERGY[i].label);b.setAttribute('role','radio');b.onclick=()=>setEnergy(p,i);dots.appendChild(b)}
        slider.addEventListener('input',()=>{phases[p].duration=parseInt(slider.value);refreshPhase(p);updateTotal()});
        updateEnergyDots(p);refreshPhase(p);
    });
    updateTotal();
}
function setEnergy(p,l){phases[p].energy=l;updateEnergyDots(p);refreshPhase(p)}
function updateEnergyDots(p){document.querySelector(`.energy-phase[data-phase="${p}"]`).querySelectorAll('.energy-dot').forEach(d=>{const sel=parseInt(d.dataset.level)===phases[p].energy;d.classList.toggle('selected',sel);d.setAttribute('aria-checked',sel?'true':'false')})}
function refreshPhase(p){const el=document.querySelector(`.energy-phase[data-phase="${p}"]`);el.querySelector('.phase-duration').textContent=phases[p].duration+' min';el.querySelector('.phase-energy-label').textContent=ENERGY[phases[p].energy].label}
function updateTotal(){const t=phases[1].duration+phases[2].duration+phases[3].duration,h=Math.floor(t/60),m=t%60;document.getElementById('total-duration').textContent=h>0?`${h}h ${m}min`:`${m} min`}

/* ═══════════════════════════════════════════════════════════════
   TOAST
   ═══════════════════════════════════════════════════════════════ */
function showToast(m){
    document.querySelectorAll('.toast').forEach(t=>t.remove());
    const el=document.createElement('div');el.className='toast';
    el.style.cssText='position:fixed;top:max(20px,var(--safe-top));left:50%;transform:translateX(-50%);padding:10px 24px;background:var(--text);color:white;font-size:13px;font-family:var(--sans);font-weight:500;border-radius:100px;z-index:999;animation:toastIn .3s var(--ease);letter-spacing:.01em;white-space:nowrap;max-width:90vw;overflow:hidden;text-overflow:ellipsis';
    el.textContent=m;document.body.appendChild(el);
    setTimeout(()=>{el.style.animation='toastOut .3s var(--ease) forwards';setTimeout(()=>el.remove(),300)},2000);
}

function fmt(s){if(!s||s<0)return'0:00';const m=Math.floor(s/60),r=Math.floor(s%60);return`${m}:${r.toString().padStart(2,'0')}`}

