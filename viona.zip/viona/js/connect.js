/* ═══════════════════════════════════════════════════════════════
   CONNECT SCREEN
   ═══════════════════════════════════════════════════════════════ */

/* ─────────────────────────────────────────────────────────────
   APPLE MUSIC — EMBEDDED DEVELOPER TOKEN
   ─────────────────────────────────────────────────────────────
   Replace the placeholder below with your actual JWT.
   Generate with your .p8 key at https://developer.apple.com
   The token is yours as the developer — users authenticate
   via Apple's popup.
   ───────────────────────────────────────────────────────────── */
const APPLE_DEVELOPER_TOKEN = 'PASTE_YOUR_JWT_HERE';

async function connectAppleMusic(){
    const btn = document.getElementById('apple-connect-btn-main');
    const errEl = document.getElementById('apple-error');
    errEl.style.display='none';

    if (APPLE_DEVELOPER_TOKEN === 'PASTE_YOUR_JWT_HERE') {
        errEl.style.display='block';
        errEl.textContent = 'Apple Music requires a developer token. Add your JWT to the code, or use Demo mode.';
        return;
    }

    const origHTML = btn.innerHTML;
    btn.style.opacity='0.6';btn.style.pointerEvents='none';
    btn.querySelector('div > div:first-child').textContent='Connecting…';

    try {
        await MusicKit.configure({
            developerToken: APPLE_DEVELOPER_TOKEN,
            app: { name: 'Viona', build: '1.0.0' }
        });
        musicInstance = MusicKit.getInstance();
        await musicInstance.authorize();
        serviceMode = 'apple';
        setBadge('apple');
        showScreen('setup-screen');
    } catch(e) {
        console.error('Apple Music auth error:', e);
        btn.innerHTML = origHTML;
        btn.style.opacity='1';btn.style.pointerEvents='auto';
        errEl.style.display='block';
        errEl.textContent = (e.message || 'Connection failed.') + ' You can try again or use Demo mode.';
    }
}

function startDemo(){serviceMode='demo';setBadge('demo');showScreen('setup-screen')}
function setBadge(m){const b=document.getElementById('connection-badge');if(m==='apple'){b.className='badge badge-apple';b.innerHTML='● Apple Music'}else{b.className='badge badge-demo';b.innerHTML='◌ Demo'}}

