/* ═══════════════════════════════════════════════════════════════
   [NEW] PREFERENCE ENGINE
   ─────────────────────────────────────────────────────────────
   In-memory preference model that accumulates like/dislike signals
   and re-ranks the upcoming queue without interrupting playback.

   SCORING WEIGHT TUNING: adjust the constants in scoreTrack().
   ═══════════════════════════════════════════════════════════════ */
const preferences = {
    likedTrackIds: new Set(),
    dislikedTrackIds: new Set(),
    likedArtists: new Map(),   // artist → positive weight
    dislikedArtists: new Map(),// artist → negative weight
    likedGenres: new Map(),
    dislikedGenres: new Map(),
    likedMoods: new Map(),
    dislikedMoods: new Map(),
    reasonSignals: [],         // keywords extracted from dislike reasons
    consecutiveDislikes: 0,    // track how many dislikes in a row
};

/**
 * recordFeedback(track, type, reason?)
 * Records a like or dislike for the given track and updates preference maps.
 * Does NOT affect playback. Persists to localStorage.
 */
function recordFeedback(track, type, reason) {
    const artist = (track.artist || '').toLowerCase();
    const genre = (track.genre || inferGenre(track)).toLowerCase();
    const mood = (track.mood || inferMood(track)).toLowerCase();

    if (type === 'like') {
        preferences.likedTrackIds.add(track.id || track.name);
        preferences.dislikedTrackIds.delete(track.id || track.name); // remove conflict
        incrementMap(preferences.likedArtists, artist, 1);
        if (genre) incrementMap(preferences.likedGenres, genre, 1);
        if (mood) incrementMap(preferences.likedMoods, mood, 1);
        preferences.consecutiveDislikes = 0;
    } else if (type === 'dislike') {
        preferences.dislikedTrackIds.add(track.id || track.name);
        preferences.likedTrackIds.delete(track.id || track.name);
        incrementMap(preferences.dislikedArtists, artist, 1);
        if (genre) incrementMap(preferences.dislikedGenres, genre, 1);
        if (mood) incrementMap(preferences.dislikedMoods, mood, 1);
        preferences.consecutiveDislikes++;
        if (reason && reason.trim()) {
            const keywords = reason.toLowerCase().split(/[\s,;.]+/).filter(w => w.length > 2);
            preferences.reasonSignals.push(...keywords);
        }
    }
    savePreferences(); // persist
}

function incrementMap(map, key, val) {
    if (!key) return;
    map.set(key, (map.get(key) || 0) + val);
}

/** Infer genre from track metadata text (name, artist, album) — broad keyword map + artist lookup */
function inferGenre(track) {
    const text = `${track.name} ${track.artist} ${track.album || ''}`.toLowerCase();
    const genreMap = {
        'jazz':['jazz','swing','bebop','bossa','bossa nova','big band','blue note'],
        'pop':['pop','hit','top 40','chart'],
        'indie':['indie','alternative','alt-','lo-fi','lofi','shoegaze','dream pop'],
        'electronic':['electronic','electro','edm','house','techno','synth','ambient','trance','dubstep','dnb','drum and bass','chillwave'],
        'classical':['classical','symphony','concerto','sonata','opus','orchestr','philharmon','chamber','baroque','romantic era','piano solo','nocturne'],
        'r&b':['r&b','rnb','neo-soul','neo soul','motown'],
        'soul':['soul','soul music','tamla'],
        'rock':['rock','grunge','garage','hard rock','classic rock','prog rock','psychedelic'],
        'metal':['metal','metallic','thrash','death metal','heavy metal','doom','black metal','nu-metal'],
        'punk':['punk','hardcore','post-punk','pop punk','emo'],
        'folk':['folk','acoustic','singer-songwriter','country','bluegrass','americana','campfire'],
        'blues':['blues','delta blues','chicago blues','twelve-bar','12-bar'],
        'hip-hop':['hip-hop','hip hop','rap','trap','boom bap','mc ','emcee','grime','drill'],
        'latin':['latin','salsa','reggaeton','cumbia','bachata','merengue','samba','tango','bossa','mariachi','corrido'],
        'reggae':['reggae','ska','dub','dancehall','rocksteady','roots'],
        'funk':['funk','funky','p-funk','disco','boogie'],
        'world':['world','afrobeat','afro','highlife','qawwali','flamenco','fado','celtic','balkan','klezmer','raga','gamelan']
    };
    for (const [genre, words] of Object.entries(genreMap)) {
        if (words.some(w => text.includes(w))) return genre;
    }
    // Known artist → genre lookup for common cases
    const artistGenre = {
        // Jazz
        'norah jones':'jazz','miles davis':'jazz','chet baker':'jazz','dave brubeck':'jazz',
        'bill evans':'jazz','ella fitzgerald':'jazz','frank sinatra':'jazz','nina simone':'jazz',
        'thelonious monk':'jazz','oliver nelson':'jazz','stan getz':'jazz','erroll garner':'jazz',
        'joão gilberto':'jazz','john coltrane':'jazz','herbie hancock':'jazz','charlie parker':'jazz',
        'duke ellington':'jazz','louis armstrong':'jazz','billie holiday':'jazz','wynton marsalis':'jazz',
        // Pop
        'the weeknd':'pop','dua lipa':'pop','taylor swift':'pop','adele':'pop','ed sheeran':'pop',
        'billie eilish':'pop','harry styles':'pop','olivia rodrigo':'pop','ariana grande':'pop',
        'justin bieber':'pop','selena gomez':'pop','pharrell':'pop','post malone':'pop',
        'dionne warwick':'pop','jvke':'pop',
        // Indie
        'phoebe bridgers':'indie','glass animals':'indie','beach house':'indie','arctic monkeys':'indie',
        'tame impala':'indie','radiohead':'indie','the strokes':'indie','bon iver':'indie',
        'sufjan stevens':'indie','fleet foxes':'indie','vampire weekend':'indie','grouplove':'indie',
        'florence + the machine':'indie','florence and the machine':'indie',
        // Electronic
        'deadmau5':'electronic','m83':'electronic','the xx':'electronic','massive attack':'electronic',
        'daft punk':'electronic','aphex twin':'electronic','boards of canada':'electronic','moby':'electronic',
        'four tet':'electronic','bonobo':'electronic','the prodigy':'electronic','tiësto':'electronic',
        'calvin harris':'electronic','skrillex':'electronic',
        // R&B / Soul
        'frank ocean':'r&b','sza':'r&b','daniel caesar':'r&b','childish gambino':'soul',
        'stevie wonder':'soul','sam cooke':'soul','aretha franklin':'soul','marvin gaye':'soul',
        'al green':'soul','otis redding':'soul','ray charles':'soul','whitney houston':'r&b',
        'alicia keys':'r&b','usher':'r&b','beyoncé':'r&b','beyonce':'r&b',
        // Classical
        'debussy':'classical','satie':'classical','vivaldi':'classical','barber':'classical',
        'wagner':'classical','beethoven':'classical','mozart':'classical','chopin':'classical',
        'bach':'classical','tchaikovsky':'classical','brahms':'classical','schubert':'classical',
        // Rock
        'eagles':'rock','queen':'rock','led zeppelin':'rock','pink floyd':'rock','ac/dc':'rock',
        'red hot chili peppers':'rock','foo fighters':'rock','nirvana':'rock','u2':'rock',
        'the rolling stones':'rock','the beatles':'rock','jimi hendrix':'rock','aerosmith':'rock',
        'david bowie':'rock','bruce springsteen':'rock','the who':'rock',
        // Hip-Hop
        'kendrick lamar':'hip-hop','notorious b.i.g':'hip-hop','travis scott':'hip-hop',
        'eminem':'hip-hop','j. cole':'hip-hop','drake':'hip-hop','kanye west':'hip-hop',
        'jay-z':'hip-hop','nas':'hip-hop','tyler, the creator':'hip-hop','a$ap rocky':'hip-hop',
        'lil wayne':'hip-hop','50 cent':'hip-hop','outkast':'hip-hop',
        // Folk
        'tracy chapman':'folk','bon iver':'folk','the lumineers':'folk','lord huron':'folk',
        'edward sharpe':'folk','bob dylan':'folk','joni mitchell':'folk','nick drake':'folk',
        'iron & wine':'folk','simon & garfunkel':'folk','cat stevens':'folk',
        // Latin
        'luis fonsi':'latin','enrique iglesias':'latin','andrea bocelli':'latin','santana':'latin',
        'don omar':'latin','bad bunny':'latin','j balvin':'latin','shakira':'latin','daddy yankee':'latin',
        // Blues
        'b.b. king':'blues','robert johnson':'blues','stevie ray vaughan':'blues','albert king':'blues',
        'muddy waters':'blues','howlin\' wolf':'blues','john lee hooker':'blues','buddy guy':'blues',
        // Reggae
        'bob marley':'reggae','ub40':'reggae','peter tosh':'reggae','jimmy cliff':'reggae','toots':'reggae',
        // Metal
        'metallica':'metal','system of a down':'metal','slayer':'metal','iron maiden':'metal',
        'black sabbath':'metal','megadeth':'metal','pantera':'metal','tool':'metal',
        // Funk
        'james brown':'funk','parliament':'funk','chic':'funk','the meters':'funk',
        'earth, wind & fire':'funk','kool & the gang':'funk','prince':'funk','bootsy collins':'funk',
        // World
        'miriam makeba':'world','buena vista social club':'world','sergio mendes':'world',
        'salif keita':'world','fela kuti':'world','ravi shankar':'world','nusrat fateh ali khan':'world',
        'cesaria evora':'world','youssou n\'dour':'world',
    };
    const artistLower = (track.artist || '').toLowerCase();
    for (const [a, g] of Object.entries(artistGenre)) {
        if (artistLower.includes(a)) return g;
    }
    // Check custom genres from user input
    for (const customGenre of activeChips.genre) {
        if (text.includes(customGenre.toLowerCase())) return customGenre.toLowerCase();
    }
    return [...activeChips.genre][0] || '';
}

/** Infer mood from track metadata text — broad keyword map + duration heuristic */
function inferMood(track) {
    const text = `${track.name} ${track.artist} ${track.album || ''}`.toLowerCase();
    const moodWords = {
        chill:['chill','calm','relax','easy','soft','gentle','peaceful','quiet','ambient','lo-fi','lofi','smooth','mellow','breeze','float','drift','lazy','sunday','coast'],
        romantic:['love','heart','romance','kiss','dream','darling','baby','sweetheart','tender','forever','beautiful','serenade','moonlight','valentine','desire','passion','my girl','my love','honey'],
        energetic:['energy','dance','fire','wild','fast','party','bounce','jump','hype','move','beat','bang','rave','power','thunder','ride','scream','run','rush','riot','rage','smash'],
        melancholy:['blue','sad','rain','cry','alone','lonely','lost','broken','tears','shadow','grey','gray','cold','empty','pain','miss','gone','farewell','goodbye','sorrow','hurt','regret','weep'],
        focus:['focus','concentrate','study','work','think','mind','deep','meditat','contempl','zone','flow','steady','minimal','ambient','instrumental'],
        uplifting:['uplift','happy','joy','sun','bright','hope','free','alive','celebrate','wonderful','amazing','beautiful day','shine','smile','glory','triumph','rise','soar','fly','freedom','wonderful'],
        dark:['dark','night','midnight','shadow','evil','demon','hell','doom','death','fear','nightmare','haunt','wicked','sinister','venom','abyss','black','blood','phantom','ghost'],
        groovy:['groove','groovy','funky','funk','disco','boogie','swing','strut','bass','rhythm','jam','vibe','slick','tight','pocket','bounce','step']
    };
    for (const [mood, words] of Object.entries(moodWords)) {
        if (words.some(w => text.includes(w))) return mood;
    }
    // Energy-based heuristic
    const e = track.energy || 0;
    if (e >= 4) return 'energetic';
    if (e <= 1) return 'chill';
    // Duration heuristic
    const dur = track.duration || 200;
    if (dur < 150) return 'energetic';
    if (dur > 400) return 'chill';
    return [...activeChips.mood][0] || 'chill';
}

/**
 * [FIXED] ENERGY-PHASE INTEGRATION
 * Maps the session timeline to the user's energy-flow curve so the queue
 * actually follows the Start → Peak → End arc the user configured.
 */

/** Returns the target energy level (1-5) for a given elapsed-seconds value */
function getTargetEnergyAtTime(elapsedSec) {
    const p1End = phases[1].duration * 60;          // seconds
    const p2End = p1End + phases[2].duration * 60;
    const p3End = p2End + phases[3].duration * 60;

    if (elapsedSec < p1End) return phases[1].energy;
    if (elapsedSec < p2End) return phases[2].energy;
    return phases[3].energy;
}

/** Returns the target energy for a track at a given queue index,
 *  by summing durations of all tracks before it. */
function getTargetEnergyForIndex(idx) {
    let cumSec = 0;
    for (let i = 0; i < idx && i < currentQueue.length; i++) {
        cumSec += (currentQueue[i].duration || 180);
    }
    return getTargetEnergyAtTime(cumSec);
}

/** Returns the current phase target energy based on real elapsed session time */
function getCurrentPhaseEnergy() {
    if (!sessionStartTime) return phases[1].energy;
    const elapsed = (Date.now() - sessionStartTime) / 1000;
    return getTargetEnergyAtTime(elapsed);
}

/** Returns the effective energy of a track (uses metadata or infers) */
function getTrackEnergy(track) {
    if (track.energy && track.energy >= 1 && track.energy <= 5) return track.energy;
    // Infer from mood if no energy tag
    const mood = (track.mood || inferMood(track)).toLowerCase();
    const moodEnergy = {chill:2, romantic:2, melancholy:1, energetic:4};
    return moodEnergy[mood] || 3;
}

/**
 * scoreTrack(track, targetEnergy)
 * Returns a numeric score for ranking a track in the upcoming queue.
 * [FIXED] Now accepts targetEnergy from the phase system.
 *
 * ──── TUNING WEIGHTS ────────────────────────────────────────────
 * Adjust these constants to change how aggressively feedback affects the queue.
 */
function scoreTrack(track, targetEnergy) {
    /* ── WEIGHTS (tweak these) ──────────── */
    const W_LIKED_ARTIST   =  3.0;  // bonus per like-count for matching artist
    const W_DISLIKED_ARTIST = -4.0;  // penalty per dislike-count for matching artist
    const W_LIKED_GENRE    =  2.0;
    const W_DISLIKED_GENRE = -2.5;
    const W_LIKED_MOOD     =  1.5;
    const W_DISLIKED_MOOD  = -2.0;
    const W_LIKED_TRACK    =  5.0;   // bonus if this exact track was liked before (re-queue)
    const W_DISLIKED_TRACK = -100;   // hard penalty — effectively remove from queue
    const W_SESSION_GENRE  =  1.0;   // bonus if track matches session genres
    const W_SESSION_MOOD   =  0.8;   // bonus if track matches session moods
    const W_REASON_PENALTY = -1.0;   // penalty per matching reason keyword
    const W_EXPLORATION    =  0.3;   // small random factor
    const W_WIDEN_ON_DISLIKES = 0.15; // extra exploration per consecutive dislike
    const W_ENERGY_MATCH   =  4.0;   // [FIXED] bonus for energy matching the current phase
    const W_ENERGY_PENALTY = -1.5;   // [FIXED] penalty per energy-level distance from target
    /* ──────────────────────────────────── */

    let score = 0;
    const trackId = track.id || track.name;
    const artist = (track.artist || '').toLowerCase();
    const genre = (track.genre || inferGenre(track)).toLowerCase();
    const mood = (track.mood || inferMood(track)).toLowerCase();
    const textBlob = `${track.name} ${track.artist} ${track.album || ''}`.toLowerCase();

    // Exact-track feedback
    if (preferences.likedTrackIds.has(trackId)) score += W_LIKED_TRACK;
    if (preferences.dislikedTrackIds.has(trackId)) score += W_DISLIKED_TRACK;

    // Artist affinity
    if (artist && preferences.likedArtists.has(artist))
        score += preferences.likedArtists.get(artist) * W_LIKED_ARTIST;
    if (artist && preferences.dislikedArtists.has(artist))
        score += preferences.dislikedArtists.get(artist) * W_DISLIKED_ARTIST;

    // Genre affinity
    if (genre && preferences.likedGenres.has(genre))
        score += preferences.likedGenres.get(genre) * W_LIKED_GENRE;
    if (genre && preferences.dislikedGenres.has(genre))
        score += preferences.dislikedGenres.get(genre) * W_DISLIKED_GENRE;

    // Mood affinity
    if (mood && preferences.likedMoods.has(mood))
        score += preferences.likedMoods.get(mood) * W_LIKED_MOOD;
    if (mood && preferences.dislikedMoods.has(mood))
        score += preferences.dislikedMoods.get(mood) * W_DISLIKED_MOOD;

    // Session anchoring — keep tracks that fit the original vibe
    // [FIXED] Use genre affinity: related genres get partial bonus
    const GENRE_AFFINITY = {
        'jazz':['blues','soul','r&b','funk','latin'],
        'blues':['jazz','soul','rock','folk'],
        'soul':['r&b','funk','jazz','blues','pop'],
        'r&b':['soul','hip-hop','pop','funk'],
        'funk':['soul','r&b','disco','electronic','groovy'],
        'rock':['metal','indie','blues','punk','folk'],
        'metal':['rock','punk'],
        'punk':['rock','metal','indie'],
        'indie':['rock','folk','electronic','pop'],
        'folk':['indie','blues','country','rock'],
        'electronic':['pop','indie','hip-hop','funk'],
        'hip-hop':['r&b','electronic','pop','soul'],
        'pop':['r&b','electronic','indie','soul'],
        'latin':['jazz','world','pop','reggae'],
        'reggae':['latin','world','soul','funk'],
        'classical':['world'],
        'world':['latin','reggae','jazz','folk','classical'],
    };
    for (const sg of activeChips.genre) {
        const sgLower = sg.toLowerCase();
        if (genre === sgLower) {
            score += W_SESSION_GENRE; // exact match
        } else if (GENRE_AFFINITY[sgLower] && GENRE_AFFINITY[sgLower].includes(genre)) {
            score += W_SESSION_GENRE * 0.5; // related genre: half bonus
        }
    }
    for (const sm of activeChips.mood) {
        if (mood.includes(sm.toLowerCase())) score += W_SESSION_MOOD;
    }

    // [FIXED] Energy-phase matching — the core of the "AI model"
    if (typeof targetEnergy === 'number' && targetEnergy >= 1) {
        const trackEnergy = getTrackEnergy(track);
        const distance = Math.abs(trackEnergy - targetEnergy);
        if (distance === 0) {
            score += W_ENERGY_MATCH;
        } else {
            score += distance * W_ENERGY_PENALTY;
        }
    }

    // Reason-signal penalties (e.g. user said "too slow" — penalize tracks with "slow" in name)
    for (const kw of preferences.reasonSignals) {
        if (textBlob.includes(kw)) score += W_REASON_PENALTY;
    }

    // Mild exploration factor — widen when user hits consecutive dislikes
    const explorationBoost = preferences.consecutiveDislikes * W_WIDEN_ON_DISLIKES;
    score += (Math.random() * (W_EXPLORATION + explorationBoost));

    return score;
}

/**
 * [NEW] Artist-spread guardrail: after scoring, push down tracks whose
 * artist appeared in the previous N slots to avoid back-to-back repeats.
 * MAX_CONSECUTIVE_SAME_ARTIST = 1 means no two adjacent tracks from same artist.
 */
const MAX_CONSECUTIVE_SAME_ARTIST = 1;

/**
 * rerankUpcomingQueue()
 * Re-sorts tracks AFTER currentTrackIndex by score (descending),
 * then applies artist-spread to avoid repetition. Updates Up Next UI.
 */
function rerankUpcomingQueue() {
    if (!currentQueue.length || currentQueue.length <= currentTrackIndex + 1) return;

    const upcoming = currentQueue.slice(currentTrackIndex + 1);

    // [FIXED] Score each track against the energy target for its tentative position
    // First pass: score with a rough target (current phase energy)
    const currentTarget = getCurrentPhaseEnergy();
    upcoming.sort((a, b) => scoreTrack(b, currentTarget) - scoreTrack(a, currentTarget));

    // [FIXED] Second pass: refine — compute per-slot target energy and re-sort
    // We build cumulative duration from the current track forward
    let cumSec = 0;
    for (let i = 0; i <= currentTrackIndex && i < currentQueue.length; i++) {
        cumSec += (currentQueue[i].duration || 180);
    }
    const scored = upcoming.map((t, i) => {
        const slotSec = cumSec + upcoming.slice(0, i).reduce((s, tr) => s + (tr.duration || 180), 0);
        const target = getTargetEnergyAtTime(slotSec);
        return { track: t, score: scoreTrack(t, target) };
    });
    scored.sort((a, b) => b.score - a.score);
    const sorted = scored.map(s => s.track);

    // Artist-spread: greedily reorder so same artist doesn't appear within N consecutive slots
    const spread = [];
    const remaining = [...sorted];
    const currentArtist = currentQueue[currentTrackIndex]
        ? (currentQueue[currentTrackIndex].artist || '').toLowerCase()
        : '';
    const recentArtists = currentArtist ? [currentArtist] : [];

    while (remaining.length > 0) {
        let picked = -1;
        for (let i = 0; i < remaining.length; i++) {
            const a = (remaining[i].artist || '').toLowerCase();
            const recent = recentArtists.slice(-MAX_CONSECUTIVE_SAME_ARTIST);
            if (!recent.includes(a)) { picked = i; break; }
        }
        if (picked === -1) picked = 0;
        const track = remaining.splice(picked, 1)[0];
        recentArtists.push((track.artist || '').toLowerCase());
        spread.push(track);
    }

    currentQueue = [
        ...currentQueue.slice(0, currentTrackIndex + 1),
        ...spread
    ];
    updateUpNext();
}

/** Reset preferences (called when starting a new session) */
function resetPreferences() {
    preferences.likedTrackIds.clear();
    preferences.dislikedTrackIds.clear();
    preferences.likedArtists.clear();
    preferences.dislikedArtists.clear();
    preferences.likedGenres.clear();
    preferences.dislikedGenres.clear();
    preferences.likedMoods.clear();
    preferences.dislikedMoods.clear();
    preferences.reasonSignals = [];
    preferences.consecutiveDislikes = 0;
    // Try loading saved prefs from a previous session
    loadPreferences();
}

/* ═══════════════════════════════════════════════════════════════
   [NEW] LOCALSTORAGE PERSISTENCE
   ─────────────────────────────────────────────────────────────
   Lightweight: only stores liked/disliked track IDs, artist
   weights, and reason signals. Silently fails if storage is
   unavailable (private browsing, quota exceeded, etc).
   ═══════════════════════════════════════════════════════════════ */
const PREFS_KEY = 'viona_prefs_v1';

function savePreferences() {
    try {
        const data = {
            likedTrackIds: [...preferences.likedTrackIds],
            dislikedTrackIds: [...preferences.dislikedTrackIds],
            likedArtists: [...preferences.likedArtists],
            dislikedArtists: [...preferences.dislikedArtists],
            likedGenres: [...preferences.likedGenres],
            dislikedGenres: [...preferences.dislikedGenres],
            likedMoods: [...preferences.likedMoods],
            dislikedMoods: [...preferences.dislikedMoods],
            reasonSignals: preferences.reasonSignals.slice(-50), // cap at 50
        };
        localStorage.setItem(PREFS_KEY, JSON.stringify(data));
    } catch (e) { /* silent — storage may be unavailable */ }
}

function loadPreferences() {
    try {
        const raw = localStorage.getItem(PREFS_KEY);
        if (!raw) return;
        const data = JSON.parse(raw);
        if (data.likedTrackIds) data.likedTrackIds.forEach(id => preferences.likedTrackIds.add(id));
        if (data.dislikedTrackIds) data.dislikedTrackIds.forEach(id => preferences.dislikedTrackIds.add(id));
        if (data.likedArtists) data.likedArtists.forEach(([k,v]) => preferences.likedArtists.set(k, v));
        if (data.dislikedArtists) data.dislikedArtists.forEach(([k,v]) => preferences.dislikedArtists.set(k, v));
        if (data.likedGenres) data.likedGenres.forEach(([k,v]) => preferences.likedGenres.set(k, v));
        if (data.dislikedGenres) data.dislikedGenres.forEach(([k,v]) => preferences.dislikedGenres.set(k, v));
        if (data.likedMoods) data.likedMoods.forEach(([k,v]) => preferences.likedMoods.set(k, v));
        if (data.dislikedMoods) data.dislikedMoods.forEach(([k,v]) => preferences.dislikedMoods.set(k, v));
        if (data.reasonSignals) preferences.reasonSignals = data.reasonSignals;
    } catch (e) { /* silent — corrupt or unavailable */ }
}

