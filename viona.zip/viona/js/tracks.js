/* ═══════════════════════════════════════════════════════════════
   VIONA — AI-Curated Music Session Player
   ═══════════════════════════════════════════════════════════════ */

const ENERGY={1:{label:'Very Low',color:'#6b9dce'},2:{label:'Low',color:'#7bb87e'},3:{label:'Medium',color:'#c9a84c'},4:{label:'High',color:'#d08350'},5:{label:'Very High',color:'#c45a5a'}};

/* [FIXED] Diverse demo library — 11 genres, 8 moods, energies 1-5 */
const DEMO_TRACKS=[
    // ── Jazz ──
    {id:'d1',name:'Come Away With Me',artist:'Norah Jones',album:'Come Away With Me',duration:198,artUrl:'',genre:'Jazz',mood:'Chill',energy:2},
    {id:'d2',name:'Feeling Good',artist:'Nina Simone',album:'I Put a Spell on You',duration:175,artUrl:'',genre:'Jazz',mood:'Uplifting',energy:3},
    {id:'d3',name:'Blue in Green',artist:'Miles Davis',album:'Kind of Blue',duration:328,artUrl:'',genre:'Jazz',mood:'Melancholy',energy:1},
    {id:'d4',name:'The Girl from Ipanema',artist:'Stan Getz',album:'Getz/Gilberto',duration:212,artUrl:'',genre:'Jazz',mood:'Chill',energy:2},
    {id:'d5',name:'Corcovado',artist:'João Gilberto',album:'Getz/Gilberto',duration:198,artUrl:'',genre:'Jazz',mood:'Romantic',energy:2},
    {id:'d6',name:'So What',artist:'Miles Davis',album:'Kind of Blue',duration:564,artUrl:'',genre:'Jazz',mood:'Chill',energy:2},
    {id:'d7',name:'Fly Me to the Moon',artist:'Frank Sinatra',album:'It Might as Well Be Swing',duration:150,artUrl:'',genre:'Jazz',mood:'Romantic',energy:3},
    {id:'d8',name:'My Funny Valentine',artist:'Chet Baker',album:'Chet Baker Sings',duration:160,artUrl:'',genre:'Jazz',mood:'Romantic',energy:1},
    {id:'d9',name:'Take Five',artist:'Dave Brubeck',album:'Time Out',duration:324,artUrl:'',genre:'Jazz',mood:'Groovy',energy:3},
    {id:'d10',name:'Autumn Leaves',artist:'Bill Evans',album:'Portrait in Jazz',duration:304,artUrl:'',genre:'Jazz',mood:'Melancholy',energy:2},
    {id:'d11',name:'Misty',artist:'Erroll Garner',album:'Concert by the Sea',duration:180,artUrl:'',genre:'Jazz',mood:'Romantic',energy:2},
    {id:'d12',name:'Night and Day',artist:'Ella Fitzgerald',album:'Ella Fitzgerald Sings the Cole Porter Songbook',duration:198,artUrl:'',genre:'Jazz',mood:'Chill',energy:3},
    {id:'d13',name:'Round Midnight',artist:'Thelonious Monk',album:"Monk's Music",duration:340,artUrl:'',genre:'Jazz',mood:'Dark',energy:1},
    {id:'d14',name:'Stolen Moments',artist:'Oliver Nelson',album:'The Blues and the Abstract Truth',duration:556,artUrl:'',genre:'Jazz',mood:'Focus',energy:2},
    // ── Pop ──
    {id:'d15',name:'Alfie',artist:'Dionne Warwick',album:'Here Where There Is Love',duration:170,artUrl:'',genre:'Pop',mood:'Romantic',energy:2},
    {id:'d16',name:'Blinding Lights',artist:'The Weeknd',album:'After Hours',duration:200,artUrl:'',genre:'Pop',mood:'Energetic',energy:5},
    {id:'d17',name:'Levitating',artist:'Dua Lipa',album:'Future Nostalgia',duration:203,artUrl:'',genre:'Pop',mood:'Energetic',energy:4},
    {id:'d18',name:'Someone Like You',artist:'Adele',album:'21',duration:285,artUrl:'',genre:'Pop',mood:'Melancholy',energy:2},
    {id:'d19',name:'Golden Hour',artist:'JVKE',album:'This Is What ____ Feels Like',duration:210,artUrl:'',genre:'Pop',mood:'Romantic',energy:2},
    {id:'d20',name:'Cruel Summer',artist:'Taylor Swift',album:'Lover',duration:178,artUrl:'',genre:'Pop',mood:'Energetic',energy:4},
    {id:'d21',name:'Sunflower',artist:'Post Malone',album:'Spider-Man: Into the Spider-Verse',duration:158,artUrl:'',genre:'Pop',mood:'Uplifting',energy:3},
    {id:'d22',name:'Happy',artist:'Pharrell Williams',album:'G I R L',duration:233,artUrl:'',genre:'Pop',mood:'Uplifting',energy:4},
    // ── Indie ──
    {id:'d23',name:'Motion Sickness',artist:'Phoebe Bridgers',album:'Stranger in the Alps',duration:222,artUrl:'',genre:'Indie',mood:'Melancholy',energy:2},
    {id:'d24',name:'Heat Waves',artist:'Glass Animals',album:'Dreamland',duration:234,artUrl:'',genre:'Indie',mood:'Chill',energy:3},
    {id:'d25',name:'Myth',artist:'Beach House',album:'Bloom',duration:244,artUrl:'',genre:'Indie',mood:'Chill',energy:2},
    {id:'d26',name:'Do I Wanna Know?',artist:'Arctic Monkeys',album:'AM',duration:272,artUrl:'',genre:'Indie',mood:'Dark',energy:3},
    {id:'d27',name:'Tongue Tied',artist:'Grouplove',album:'Never Trust a Happy Song',duration:199,artUrl:'',genre:'Indie',mood:'Energetic',energy:5},
    {id:'d28',name:'Dog Days Are Over',artist:'Florence + The Machine',album:'Lungs',duration:250,artUrl:'',genre:'Indie',mood:'Uplifting',energy:4},
    // ── Electronic ──
    {id:'d29',name:'Midnight City',artist:'M83',album:'Hurry Up, We\'re Dreaming',duration:244,artUrl:'',genre:'Electronic',mood:'Energetic',energy:4},
    {id:'d30',name:'Strobe',artist:'Deadmau5',album:'For Lack of a Better Name',duration:637,artUrl:'',genre:'Electronic',mood:'Focus',energy:3},
    {id:'d31',name:'Intro',artist:'The xx',album:'xx',duration:128,artUrl:'',genre:'Electronic',mood:'Chill',energy:1},
    {id:'d32',name:'Teardrop',artist:'Massive Attack',album:'Mezzanine',duration:330,artUrl:'',genre:'Electronic',mood:'Dark',energy:2},
    {id:'d33',name:'Around the World',artist:'Daft Punk',album:'Homework',duration:428,artUrl:'',genre:'Electronic',mood:'Groovy',energy:5},
    {id:'d34',name:'Breathe',artist:'The Prodigy',album:'The Fat of the Land',duration:356,artUrl:'',genre:'Electronic',mood:'Energetic',energy:5},
    {id:'d35',name:'Porcelain',artist:'Moby',album:'Play',duration:238,artUrl:'',genre:'Electronic',mood:'Chill',energy:1},
    // ── R&B / Soul ──
    {id:'d36',name:'Best Part',artist:'Daniel Caesar',album:'Freudian',duration:217,artUrl:'',genre:'R&B',mood:'Romantic',energy:2},
    {id:'d37',name:'Earned It',artist:'The Weeknd',album:'Beauty Behind the Madness',duration:252,artUrl:'',genre:'R&B',mood:'Romantic',energy:2},
    {id:'d38',name:'Pink + White',artist:'Frank Ocean',album:'Blonde',duration:193,artUrl:'',genre:'R&B',mood:'Chill',energy:2},
    {id:'d39',name:'Love Galore',artist:'SZA',album:'Ctrl',duration:275,artUrl:'',genre:'R&B',mood:'Chill',energy:3},
    {id:'d40',name:'Redbone',artist:'Childish Gambino',album:'Awaken, My Love!',duration:327,artUrl:'',genre:'Soul',mood:'Groovy',energy:3},
    {id:'d41',name:'Superstition',artist:'Stevie Wonder',album:'Talking Book',duration:245,artUrl:'',genre:'Soul',mood:'Energetic',energy:4},
    {id:'d42',name:'A Change Is Gonna Come',artist:'Sam Cooke',album:'Ain\'t That Good News',duration:192,artUrl:'',genre:'Soul',mood:'Melancholy',energy:2},
    {id:'d43',name:'Respect',artist:'Aretha Franklin',album:'I Never Loved a Man the Way I Love You',duration:147,artUrl:'',genre:'Soul',mood:'Energetic',energy:4},
    // ── Classical ──
    {id:'d44',name:'Clair de Lune',artist:'Claude Debussy',album:'Suite bergamasque',duration:312,artUrl:'',genre:'Classical',mood:'Romantic',energy:1},
    {id:'d45',name:'Gymnopédie No. 1',artist:'Erik Satie',album:'Gymnopédies',duration:195,artUrl:'',genre:'Classical',mood:'Chill',energy:1},
    {id:'d46',name:'Adagio for Strings',artist:'Samuel Barber',album:'Orchestral Works',duration:480,artUrl:'',genre:'Classical',mood:'Melancholy',energy:2},
    {id:'d47',name:'The Four Seasons: Spring',artist:'Antonio Vivaldi',album:'The Four Seasons',duration:208,artUrl:'',genre:'Classical',mood:'Uplifting',energy:4},
    {id:'d48',name:'Ride of the Valkyries',artist:'Richard Wagner',album:'Die Walküre',duration:310,artUrl:'',genre:'Classical',mood:'Energetic',energy:5},
    {id:'d49',name:'Nocturne Op. 9 No. 2',artist:'Frédéric Chopin',album:'Nocturnes',duration:275,artUrl:'',genre:'Classical',mood:'Romantic',energy:1},
    {id:'d50',name:'Symphony No. 5',artist:'Ludwig van Beethoven',album:'Symphonies',duration:420,artUrl:'',genre:'Classical',mood:'Energetic',energy:5},
    // ── Rock ──
    {id:'d51',name:'Hotel California',artist:'Eagles',album:'Hotel California',duration:391,artUrl:'',genre:'Rock',mood:'Chill',energy:3},
    {id:'d52',name:'Bohemian Rhapsody',artist:'Queen',album:'A Night at the Opera',duration:354,artUrl:'',genre:'Rock',mood:'Energetic',energy:5},
    {id:'d53',name:'Stairway to Heaven',artist:'Led Zeppelin',album:'Led Zeppelin IV',duration:482,artUrl:'',genre:'Rock',mood:'Melancholy',energy:3},
    {id:'d54',name:'Comfortably Numb',artist:'Pink Floyd',album:'The Wall',duration:382,artUrl:'',genre:'Rock',mood:'Dark',energy:2},
    {id:'d55',name:'Back in Black',artist:'AC/DC',album:'Back in Black',duration:255,artUrl:'',genre:'Rock',mood:'Energetic',energy:5},
    {id:'d56',name:'Wish You Were Here',artist:'Pink Floyd',album:'Wish You Were Here',duration:334,artUrl:'',genre:'Rock',mood:'Melancholy',energy:2},
    {id:'d57',name:'Under the Bridge',artist:'Red Hot Chili Peppers',album:'Blood Sugar Sex Magik',duration:264,artUrl:'',genre:'Rock',mood:'Melancholy',energy:2},
    {id:'d58',name:'Everlong',artist:'Foo Fighters',album:'The Colour and the Shape',duration:250,artUrl:'',genre:'Rock',mood:'Energetic',energy:4},
    // ── Hip-Hop ──
    {id:'d59',name:'Alright',artist:'Kendrick Lamar',album:'To Pimp a Butterfly',duration:219,artUrl:'',genre:'Hip-Hop',mood:'Uplifting',energy:4},
    {id:'d60',name:'Juicy',artist:'The Notorious B.I.G.',album:'Ready to Die',duration:320,artUrl:'',genre:'Hip-Hop',mood:'Groovy',energy:3},
    {id:'d61',name:'Sicko Mode',artist:'Travis Scott',album:'Astroworld',duration:312,artUrl:'',genre:'Hip-Hop',mood:'Energetic',energy:5},
    {id:'d62',name:'Stan',artist:'Eminem',album:'The Marshall Mathers LP',duration:404,artUrl:'',genre:'Hip-Hop',mood:'Dark',energy:3},
    {id:'d63',name:'No Role Modelz',artist:'J. Cole',album:'2014 Forest Hills Drive',duration:293,artUrl:'',genre:'Hip-Hop',mood:'Chill',energy:3},
    {id:'d64',name:'Passionfruit',artist:'Drake',album:'More Life',duration:298,artUrl:'',genre:'Hip-Hop',mood:'Chill',energy:2},
    // ── Folk ──
    {id:'d65',name:'Fast Car',artist:'Tracy Chapman',album:'Tracy Chapman',duration:296,artUrl:'',genre:'Folk',mood:'Melancholy',energy:2},
    {id:'d66',name:'Skinny Love',artist:'Bon Iver',album:'For Emma, Forever Ago',duration:230,artUrl:'',genre:'Folk',mood:'Melancholy',energy:1},
    {id:'d67',name:'Ho Hey',artist:'The Lumineers',album:'The Lumineers',duration:163,artUrl:'',genre:'Folk',mood:'Uplifting',energy:3},
    {id:'d68',name:'The Night We Met',artist:'Lord Huron',album:'Strange Trails',duration:207,artUrl:'',genre:'Folk',mood:'Romantic',energy:1},
    {id:'d69',name:'Home',artist:'Edward Sharpe & The Magnetic Zeros',album:'Up from Below',duration:305,artUrl:'',genre:'Folk',mood:'Uplifting',energy:4},
    {id:'d70',name:'Blowin\' in the Wind',artist:'Bob Dylan',album:'The Freewheelin\' Bob Dylan',duration:166,artUrl:'',genre:'Folk',mood:'Focus',energy:2},
    // ── Latin ──
    {id:'d71',name:'Despacito',artist:'Luis Fonsi',album:'Vida',duration:229,artUrl:'',genre:'Latin',mood:'Energetic',energy:4},
    {id:'d72',name:'Bailando',artist:'Enrique Iglesias',album:'Sex and Love',duration:250,artUrl:'',genre:'Latin',mood:'Energetic',energy:4},
    {id:'d73',name:'Bésame Mucho',artist:'Andrea Bocelli',album:'Amore',duration:218,artUrl:'',genre:'Latin',mood:'Romantic',energy:2},
    {id:'d74',name:'Oye Como Va',artist:'Santana',album:'Abraxas',duration:256,artUrl:'',genre:'Latin',mood:'Groovy',energy:4},
    {id:'d75',name:'Danza Kuduro',artist:'Don Omar',album:'Meet the Orphans',duration:199,artUrl:'',genre:'Latin',mood:'Energetic',energy:5},
    // ── Blues ──
    {id:'d76',name:'The Thrill Is Gone',artist:'B.B. King',album:'Completely Well',duration:327,artUrl:'',genre:'Blues',mood:'Melancholy',energy:2},
    {id:'d77',name:'Crossroad Blues',artist:'Robert Johnson',album:'King of the Delta Blues Singers',duration:157,artUrl:'',genre:'Blues',mood:'Dark',energy:3},
    {id:'d78',name:'Pride and Joy',artist:'Stevie Ray Vaughan',album:'Texas Flood',duration:217,artUrl:'',genre:'Blues',mood:'Groovy',energy:4},
    {id:'d79',name:'Born Under a Bad Sign',artist:'Albert King',album:'Born Under a Bad Sign',duration:152,artUrl:'',genre:'Blues',mood:'Groovy',energy:3},
    // ── Reggae ──
    {id:'d80',name:'Three Little Birds',artist:'Bob Marley',album:'Exodus',duration:180,artUrl:'',genre:'Reggae',mood:'Uplifting',energy:2},
    {id:'d81',name:'Is This Love',artist:'Bob Marley',album:'Kaya',duration:230,artUrl:'',genre:'Reggae',mood:'Romantic',energy:2},
    {id:'d82',name:'Red Red Wine',artist:'UB40',album:'Labour of Love',duration:285,artUrl:'',genre:'Reggae',mood:'Chill',energy:2},
    // ── Metal ──
    {id:'d83',name:'Enter Sandman',artist:'Metallica',album:'Metallica',duration:332,artUrl:'',genre:'Metal',mood:'Energetic',energy:5},
    {id:'d84',name:'Chop Suey!',artist:'System of a Down',album:'Toxicity',duration:210,artUrl:'',genre:'Metal',mood:'Energetic',energy:5},
    {id:'d85',name:'Nothing Else Matters',artist:'Metallica',album:'Metallica',duration:388,artUrl:'',genre:'Metal',mood:'Melancholy',energy:2},
    {id:'d86',name:'Fade to Black',artist:'Metallica',album:'Ride the Lightning',duration:418,artUrl:'',genre:'Metal',mood:'Dark',energy:3},
    // ── Funk ──
    {id:'d87',name:'Get Up (I Feel Like Being a) Sex Machine',artist:'James Brown',album:'Sex Machine',duration:337,artUrl:'',genre:'Funk',mood:'Groovy',energy:5},
    {id:'d88',name:'Give Up the Funk',artist:'Parliament',album:'Mothership Connection',duration:356,artUrl:'',genre:'Funk',mood:'Groovy',energy:5},
    {id:'d89',name:'Le Freak',artist:'Chic',album:'C\'est Chic',duration:330,artUrl:'',genre:'Funk',mood:'Energetic',energy:4},
    {id:'d90',name:'Cissy Strut',artist:'The Meters',album:'The Meters',duration:170,artUrl:'',genre:'Funk',mood:'Groovy',energy:3},
    // ── World ──
    {id:'d91',name:'Pata Pata',artist:'Miriam Makeba',album:'Pata Pata',duration:175,artUrl:'',genre:'World',mood:'Uplifting',energy:4},
    {id:'d92',name:'Chan Chan',artist:'Buena Vista Social Club',album:'Buena Vista Social Club',duration:280,artUrl:'',genre:'World',mood:'Chill',energy:2},
    {id:'d93',name:'Mas Que Nada',artist:'Sergio Mendes',album:'Brasileiro',duration:222,artUrl:'',genre:'World',mood:'Groovy',energy:4},
    {id:'d94',name:'Waka Waka',artist:'Shakira',album:'Sale el Sol',duration:212,artUrl:'',genre:'World',mood:'Energetic',energy:5},
    {id:'d95',name:'Djembe',artist:'Salif Keita',album:'Moffou',duration:340,artUrl:'',genre:'World',mood:'Chill',energy:2},
];

const phases={1:{duration:20,energy:2},2:{duration:40,energy:4},3:{duration:20,energy:1}};
const activeChips={genre:new Set(['Jazz']),mood:new Set(['Chill'])};
let currentTrackIndex=0,isPlaying=false,serviceMode='demo',musicInstance=null,playbackInterval=null,currentQueue=[];
let _feedbackDebounce=false; // debounce flag for rapid like/dislike taps

/* [FIXED] HTML5 Audio element for preview playback */
const audioEl = new Audio();
audioEl.crossOrigin = 'anonymous';
audioEl.volume = 1.0;
let usingRealAudio = false; // true when audioEl is driving playback

/* [FIXED] Session clock — tracks elapsed seconds since session start for energy-phase mapping */
let sessionStartTime = 0;   // Date.now() when session begins
let sessionElapsedSec = 0;  // updated every tick

