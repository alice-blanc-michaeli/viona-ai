/* ═══════════════════════════════════════════════════════════════
   SESSION
   ═══════════════════════════════════════════════════════════════ */
async function startSession(){
    currentTrackIndex=0;
    resetPreferences();
    resetFeedbackUI();
    sessionStartTime = Date.now(); // [FIXED] start session clock
    showScreen('playback-screen');

    if(serviceMode==='demo'){
        currentQueue = buildPhaseAwareQueue([...DEMO_TRACKS]);
        showToast('Demo mode — playback is simulated');
        loadTrack(0);
    }
    else if(serviceMode==='apple')await loadAppleMusicQueue();
}

/**
 * [FIXED] buildPhaseAwareQueue(pool)
 * Takes a pool of tracks and returns them ordered to follow the
 * user's energy-flow curve (Start → Peak → End).
 * Also filters by session genre/mood chips when possible.
 */
function buildPhaseAwareQueue(pool) {
    const selectedGenres = new Set([...activeChips.genre].map(g => g.toLowerCase()));
    const selectedMoods = new Set([...activeChips.mood].map(m => m.toLowerCase()));

    // Build set of all acceptable genres (selected + related via affinity)
    const GENRE_AFFINITY = {
        'jazz':['blues','soul','r&b','funk','latin'],
        'blues':['jazz','soul','rock','folk'],
        'soul':['r&b','funk','jazz','blues','pop'],
        'r&b':['soul','hip-hop','pop','funk'],
        'funk':['soul','r&b','disco','electronic'],
        'rock':['metal','indie','blues','punk','folk'],
        'metal':['rock','punk'],
        'punk':['rock','metal','indie'],
        'indie':['rock','folk','electronic','pop'],
        'folk':['indie','blues','country','rock'],
        'electronic':['pop','indie','hip-hop','funk'],
        'hip-hop':['r&b','electronic','pop','soul'],
        'pop':['r&b','electronic','indie','soul'],
        'latin':['jazz','world','pop','reggae'],
        'reggae':['latin','world','soul','funk'],
        'classical':['world'],
        'world':['latin','reggae','jazz','folk','classical'],
    };
    const expandedGenres = new Set(selectedGenres);
    for (const g of selectedGenres) {
        if (GENRE_AFFINITY[g]) GENRE_AFFINITY[g].forEach(r => expandedGenres.add(r));
    }

    // Step 1: prefer tracks matching selected genres/moods (with affinity)
    let candidates = pool.filter(t => {
        const g = (t.genre || inferGenre(t)).toLowerCase();
        const m = (t.mood || inferMood(t)).toLowerCase();
        const genreOk = selectedGenres.size === 0 || selectedGenres.has(g) || expandedGenres.has(g);
        const moodOk = selectedMoods.size === 0 || selectedMoods.has(m);
        return genreOk || moodOk;
    });
    // Separate into exact matches and affinity-only matches for sorting priority
    const exactMatch = candidates.filter(t => {
        const g = (t.genre || inferGenre(t)).toLowerCase();
        return selectedGenres.has(g);
    });
    const affinityOnly = candidates.filter(t => {
        const g = (t.genre || inferGenre(t)).toLowerCase();
        return !selectedGenres.has(g);
    });
    // Prioritize exact matches but keep affinity ones available
    candidates = [...exactMatch, ...affinityOnly];
    // If too few matched, use whole pool
    if (candidates.length < 6) candidates = [...pool];

    // Step 2: build timeline slots from the 3 phases
    const slots = [];
    for (let p = 1; p <= 3; p++) {
        const phaseDurSec = phases[p].duration * 60;
        const phaseEnergy = phases[p].energy;
        let filled = 0;
        while (filled < phaseDurSec && candidates.length > 0) {
            // Find best candidate for this energy level
            let bestIdx = 0, bestScore = -Infinity;
            for (let i = 0; i < candidates.length; i++) {
                const e = getTrackEnergy(candidates[i]);
                const dist = Math.abs(e - phaseEnergy);
                const s = -dist + (Math.random() * 0.5); // slight randomness to avoid same order
                if (s > bestScore) { bestScore = s; bestIdx = i; }
            }
            const picked = candidates.splice(bestIdx, 1)[0];
            slots.push(picked);
            filled += (picked.duration || 180);
        }
    }
    // Append any remaining candidates at the end
    slots.push(...candidates);
    return slots;
}
function backToSetup(){stopPlayback();stopAudio();showScreen('setup-screen')}
function buildSearchQuery(){return[document.getElementById('intent-input').value,[...activeChips.genre].join(' '),[...activeChips.mood].join(' '),document.getElementById('free-text').value].filter(Boolean).join(' ').substring(0,100)}

