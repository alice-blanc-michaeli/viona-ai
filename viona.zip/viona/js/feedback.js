/* ═══════════════════════════════════════════════════════════════
   [CHANGED] FEEDBACK — NO LONGER INTERRUPTS PLAYBACK
   ─────────────────────────────────────────────────────────────
   handleLike()   → record positive, re-rank queue, show toast
   handleDislike() → toggle reason panel (keep playing)
   submitDislike() → record negative + reason, re-rank queue, close panel
   ═══════════════════════════════════════════════════════════════ */

/** Reset feedback button states when a new track loads */
function resetFeedbackUI() {
    const likeBtn = document.getElementById('like-btn');
    const dislikeBtn = document.getElementById('dislike-btn');
    likeBtn.classList.remove('liked','debounced');
    dislikeBtn.classList.remove('disliked','debounced');
    document.getElementById('dislike-overlay').classList.remove('open');
    document.getElementById('reason-input').value = '';
    document.getElementById('playback-screen').removeAttribute('inert');
    document.getElementById('feedback-buttons').style.display = 'flex';
    hideTunedMsg();
    _feedbackDebounce = false;
}

/** Debounce wrapper — prevents rapid-fire taps for 600ms */
function withDebounce(fn) {
    if (_feedbackDebounce) return;
    _feedbackDebounce = true;
    const btns = document.querySelectorAll('.fb-btn');
    btns.forEach(b => b.classList.add('debounced'));
    fn();
    setTimeout(() => {
        _feedbackDebounce = false;
        btns.forEach(b => b.classList.remove('debounced'));
    }, 600);
}

function handleLike() {
    withDebounce(() => {
        const track = currentQueue[currentTrackIndex];
        if (!track) return;

        const likeBtn = document.getElementById('like-btn');
        const dislikeBtn = document.getElementById('dislike-btn');

        // Toggle: if already liked, undo
        if (likeBtn.classList.contains('liked')) {
            likeBtn.classList.remove('liked');
            preferences.likedTrackIds.delete(track.id || track.name);
            savePreferences();
            showToast('Like removed');
            rerankUpcomingQueue();
            return;
        }

        // Clear opposite state
        dislikeBtn.classList.remove('disliked');
        document.getElementById('dislike-overlay').classList.remove('open');
        document.getElementById('playback-screen').removeAttribute('inert');

        likeBtn.classList.add('liked');
        recordFeedback(track, 'like');
        rerankUpcomingQueue();

        showToast('Liked — tuning your session');
        showTunedMsg('Session tuned · more like ' + track.artist);
    });
}

function handleDislike() {
    withDebounce(() => {
        const overlay = document.getElementById('dislike-overlay');
        const dislikeBtn = document.getElementById('dislike-btn');

        if (overlay.classList.contains('open')) {
            cancelDislike();
            return;
        }

        dislikeBtn.classList.add('disliked');
        overlay.classList.add('open');
        // [P1-8] Trap focus: make background inert
        document.getElementById('playback-screen').setAttribute('inert','');
        setTimeout(() => {
            const input = document.getElementById('reason-input');
            if (input) input.focus();
        }, 350);
    });
}

function cancelDislike() {
    document.getElementById('dislike-overlay').classList.remove('open');
    document.getElementById('dislike-btn').classList.remove('disliked');
    document.getElementById('reason-input').value = '';
    document.getElementById('playback-screen').removeAttribute('inert');
}

function submitDislike() {
    const track = currentQueue[currentTrackIndex];
    if (!track) return;

    const reason = document.getElementById('reason-input').value.trim();
    const likeBtn = document.getElementById('like-btn');

    likeBtn.classList.remove('liked');

    recordFeedback(track, 'dislike', reason);
    rerankUpcomingQueue();

    document.getElementById('dislike-overlay').classList.remove('open');
    document.getElementById('reason-input').value = '';
    document.getElementById('playback-screen').removeAttribute('inert');

    showToast('Got it — adjusting upcoming tracks');
    showTunedMsg('Queue adjusted · avoiding similar');
}

function showTunedMsg(text) {
    const el = document.getElementById('session-tuned-msg');
    el.textContent = text;
    el.style.display = 'block';
    // auto-hide after 4s
    clearTimeout(el._timer);
    el._timer = setTimeout(() => { el.style.display = 'none'; }, 4000);
}
function hideTunedMsg() {
    const el = document.getElementById('session-tuned-msg');
    el.style.display = 'none';
    clearTimeout(el._timer);
}

