/* ═══════════════════════════════════════════════════════════════
   APPLE MUSIC
   ═══════════════════════════════════════════════════════════════ */
async function loadAppleMusicQueue(){
    showLoadingState();
    try{
        const q=buildSearchQuery(),sf=musicInstance.storefrontId||'us';
        const r=await musicInstance.api.music('/v1/catalog/'+sf+'/search',{term:q,types:['songs'],limit:50});
        const s=r?.data?.results?.songs?.data||[];
        const mapped = s.length>0 ? s.map(mapApple) : [...DEMO_TRACKS];
        currentQueue = buildPhaseAwareQueue(mapped); // [FIXED] phase-aware ordering
        if(s.length===0) showToast('No results — using demo tracks');
        if(currentQueue.length>0)loadAppleTrack(0);
    }catch(e){
        console.error('Apple Music load error:',e);
        serviceMode = 'demo'; // Switch to demo so playback controls work correctly
        setBadge('demo');
        currentQueue=buildPhaseAwareQueue([...DEMO_TRACKS]);
        showToast('Apple Music error — using demo tracks');
        loadTrack(0);
    }
}
/** Apple mapping with energy + mood inference from genre + duration */
function mapApple(s){
    const a=s.attributes;
    const dur = Math.round((a.durationInMillis||0)/1000);
    const genreName = (a.genreNames?.[0]||'').toLowerCase();
    // Normalize Apple genre names (e.g., "Hip-Hop/Rap" → "hip-hop")
    let genre = a.genreNames?.[0]||'';
    if (genreName.includes('hip-hop') || genreName.includes('rap')) genre = 'Hip-Hop';
    else if (genreName.includes('r&b') || genreName.includes('soul')) genre = 'R&B';
    else if (genreName.includes('alternative') || genreName.includes('indie')) genre = 'Indie';
    else if (genreName.includes('dance') || genreName.includes('electronic')) genre = 'Electronic';
    else if (genreName.includes('singer') || genreName.includes('songwriter')) genre = 'Folk';
    else if (genreName.includes('latin') || genreName.includes('reggaeton')) genre = 'Latin';
    else if (genreName.includes('metal')) genre = 'Metal';
    else if (genreName.includes('punk')) genre = 'Rock';

    // Infer energy from genre + duration
    let energy = 3;
    const highEnergyGenres = ['pop','dance','electronic','hip-hop','rock','metal','punk','reggaeton'];
    const lowEnergyGenres = ['classical','ambient','jazz','new age','easy listening','singer/songwriter'];
    if (highEnergyGenres.some(g => genreName.includes(g))) energy = 4;
    if (lowEnergyGenres.some(g => genreName.includes(g))) energy = 2;
    if (dur > 360) energy = Math.max(1, energy - 1);
    if (dur < 180) energy = Math.min(5, energy + 1);

    // Infer mood from genre + track name
    const trackText = `${a.name} ${a.artistName} ${a.albumName||''}`.toLowerCase();
    let mood = '';
    const moodFromGenre = {
        'classical':'chill','ambient':'chill','easy listening':'chill','new age':'chill',
        'dance':'energetic','metal':'energetic','punk':'energetic',
        'jazz':'chill','blues':'melancholy','folk':'melancholy',
        'r&b':'romantic','soul':'romantic',
        'reggae':'chill','latin':'groovy','funk':'groovy',
    };
    for (const [g, m] of Object.entries(moodFromGenre)) {
        if (genreName.includes(g)) { mood = m; break; }
    }
    // Override with track-name keywords if detected
    const moodKeywords = {
        energetic:['party','dance','fire','wild','remix','club'],
        romantic:['love','heart','kiss','baby','dream','forever'],
        melancholy:['sad','cry','alone','rain','gone','lost','broken'],
        chill:['chill','relax','easy','soft','calm','smooth'],
        dark:['dark','night','shadow','demon','death','nightmare'],
        uplifting:['happy','sun','bright','joy','free','alive','hope'],
    };
    for (const [m, words] of Object.entries(moodKeywords)) {
        if (words.some(w => trackText.includes(w))) { mood = m; break; }
    }

    return {
        id:s.id, name:a.name,
        artist:a.artistName,
        album:a.albumName||'',
        duration:dur,
        artUrl:a.artwork?.url?a.artwork.url.replace('{w}','600').replace('{h}','600'):'',
        catalogId:s.id,
        genre: genre,
        mood: mood,
        energy: energy
    };
}
async function loadAppleTrack(i){
    // Queue recycling (same logic as loadTrack)
    if(i>=currentQueue.length){
        const pool = currentQueue.filter(t => !preferences.dislikedTrackIds.has(t.id || t.name));
        if (pool.length < 3) {
            // Not enough Apple tracks left — fall back to demo
            serviceMode = 'demo';
            setBadge('demo');
            currentQueue = buildPhaseAwareQueue([...DEMO_TRACKS]);
            showToast('Session complete — restarting with demo tracks');
            loadTrack(0);
            return;
        } else {
            sessionStartTime = Date.now();
            currentQueue = buildPhaseAwareQueue(pool);
            showToast('Reshuffling queue based on your feedback');
        }
        i = 0;
    }
    // Safety: if track has no catalogId, fall back to demo playback
    if (!currentQueue[i].catalogId) {
        loadTrack(i);
        return;
    }
    currentTrackIndex=i;
    updateTrackUI(currentQueue[i]);
    resetFeedbackUI();
    updateUpNext();
    try{
        await musicInstance.setQueue({songs:[currentQueue[i].catalogId]});
        await musicInstance.play();
        setPlayingState(true);
        startAppleMonitor();
    } catch(e){
        console.warn('Apple Music playback error for track:', currentQueue[i].name, e);
        showToast('Skipping — couldn\'t play this track');
        // Skip to next instead of simulating silence
        setTimeout(() => {
            loadAppleTrack(currentTrackIndex + 1);
        }, 500);
    }
}
function startAppleMonitor(){
    clearPlayback();
    playbackInterval=setInterval(()=>{
        if(!musicInstance)return;
        const c=musicInstance.currentPlaybackTime,t=musicInstance.currentPlaybackDuration;
        if(t>0){
            document.getElementById('progress-bar').style.width=((c/t)*100)+'%';
            document.getElementById('current-time').textContent=fmt(c);
            document.getElementById('total-time').textContent=fmt(t);
        }
        if(musicInstance.playbackState===MusicKit.PlaybackStates.completed){
            clearPlayback();setTimeout(()=>skipTrack(),800);
        }
    },500);
}

