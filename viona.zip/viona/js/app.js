/* ═══════════════════════════════════════════════════════════════
   INIT
   ═══════════════════════════════════════════════════════════════ */
(async function(){
    showScreen('connect-screen');
    initEnergyPhases();
    initProgressSeek();
    renderChips('genre');
    renderChips('mood');
    updateChipButtons('genre');
    updateChipButtons('mood');

    // [P1-8] Close dislike overlay on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') cancelDislike();
    });
    // Submit dislike on Enter in reason input
    document.getElementById('reason-input').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); submitDislike(); }
    });
})();
